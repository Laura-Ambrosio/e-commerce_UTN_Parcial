# Proyecto: Pagina ecommerce

## ✍️ Descripción

El objetivo del proyecto es poder conectar la pagina que muestra los productos con el carrito de compras.

## ⚙️ Objetivos 

1. Los productos seran agregados al carrito de compras mediante un boton "Agregar Producto" en la vista "Inicio" del FoodStore
2. Los productos agregados se almacenaran en localStorage
3. El localStorage correspondiente al carrito se visualizara en la pagina carrito (cart.html)
4. Una vez en el carrito el usuario podra aumentar y disminuir la cantidad de productos y eliminar los productos
5. Se calculara y mostrara el total de la compra
6. El usuario podra navegar desde Inicio a Carrito mediante el panel de navegacion

## 🚀 Cómo ejecutar el proyecto
1. Descomprimir el archivo.zip
2. Instalar dependencias:
pnpm install
3. Levantar el servidor de desarrollo:
pnpm dev
4. Abrir en el navegador: `http://localhost:5173`
> El proyecto redirige automáticamente al catálogo de productos.
---

## 📁 Estructura del Proyecto

Se clono el repositorio del proyecto TS anterior y se mantuvieron las carpetas.
Para evitar conflicto se comento el contenido de archivos especificos, desactivando login, registro y la redireccion asociada.

```
/
├── src/
│   ├── data/
│   │   └── data.ts               # Array de productos (PRODUCTS) y categorías (CATEGORIAS)
│   ├── pages/
│   │   ├── admin/home/           # [TP anterior - no usado en este parcial]
│   │   │   ├── home.html
│   │   │   └── home.ts
│   │   ├── auth/                 # [TP anterior - no usado en este parcial]
│   │   │   ├── login/
│   │   │   └── registro/
│   │   ├── client/home/          # [TP anterior - no usado en este parcial]
│   │   │   ├── home.html
│   │   │   └── home.ts
│   │   └── store/
│   │       ├── cart/
│   │       │   ├── cart.html     # Vista del carrito
│   │       │   └── cart.ts       # Lógica: renderizar carrito, calcular total, botones
│   │       └── home/
│   │           ├── home.html     # Catálogo de productos
│   │           └── home.ts       # Lógica: renderizar productos, búsqueda, filtros, agregar al carrito
│   ├── types/
│   │   ├── categoria.ts          # Interface Icategoria
│   │   ├── IRegisteredUsers.ts   # [TP anterior] Interface para usuarios registrados
│   │   ├── IUser.ts              # [TP anterior] Interface para sesión de usuario
│   │   ├── product.ts            # Interfaces Product y CartItem
│   │   └── Rol.ts                # [TP anterior] Tipo de rol (admin/client)
│   └── utils/                    # [TP anterior - comentado en este parcial]
│       ├── auth.ts
│       ├── localStorage.ts
│       ├── main.ts
│       └── navigate.ts
├── index.html                    # Redirige automáticamente a store/home
├── vite.config.ts                # Configuración de Vite con rutas registradas
└── README.md
```
