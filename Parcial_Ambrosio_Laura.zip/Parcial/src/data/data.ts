import type { Product } from "../types/product.ts";
import type { Icategoria } from "../types/categoria.ts";


export function getCategories(nombre: string){
    CATEGORIAS.forEach(element => {
        if(nombre === element.nombre){
            return element.nombre;
        }
    })};

// Array de categorías
export const CATEGORIAS : Array<Icategoria>= [
    {nombre:"Ver Todos"}, 
    {nombre:"Salchipapas"}, 
    {nombre:"Papas rellenas"}, 
    {nombre:"Papas Fritas"}, 
    {nombre:"Bombas de papa"}
];

//Array de productos
export const PRODUCTS : Array<Product> = [
{
id: 1,
nombre: "Salchipapas clásicas",
descripcion: "Papas fritas y salchicas con mayonesa y ketchup",
precio: 10000,
imagen: "assets/salchipapa.jpg",
categoria: "Salchipapas"
},
{
id: 2,
nombre: "Bombas de papas con queso",
descripcion: "Bombas de papa rellenas de queso con salsa a eleccion",
precio: 10000,
imagen: "assets/bombasdepapa.jfif",
categoria: "Bombas de papa"
},
{
id: 3,
nombre: "Papas rellenas con queso y cebolla",
descripcion: "Papas rellenas con queso cremoso, cebollas de verdeo y queso chedar",
precio: 15000,
imagen: "assets/paparellena.jpg",
categoria: "Papas rellenas"
},
{
id: 4,
nombre: "Papas fritas clásicas",
descripcion: "Papas fritas clásicas con adherezo a eleccion",
precio: 10000,
imagen: "assets/papasfritas.jpg",
categoria: "Papas Fritas"
},
{
id: 5,
nombre: "Papas fritas con chedar",
descripcion: "Papas fritas con queso chedar y crema de verdeo",
precio: 12000,
imagen: "assets/papasfritas.jpg",
categoria: "Papas Fritas"
},
{
id: 6,
nombre: "Papas rellenas panceta y queso",
descripcion: "Papas rellenas con panceta queso y cebolla",
precio: 20000,
imagen: "assets/paparellena.jpg",
categoria: "Papas rellenas"
},
{
id: 7,
nombre: "Bombas de papas acelga y queso",
descripcion: "Bombas de papas rellenas con acelga y queso",
precio: 15000,
imagen: "assets/bombasdepapa.jfif",
categoria: "Bombas de papa"
},
{
id: 8,
nombre: "Salchipapas picantes",
descripcion: "Papas fritas con salchicas, mayonesa y salsa tabasco",
precio: 10000,
imagen: "assets/salchipapa.jpg",
categoria: "Salchipapas"
},
];
