//Buscar el elemento que tenga la id lista-categorias en el archivo index.html
const listaCategorias = document.getElementById("lista-categorias");

//Funcion: cargar categorias
const cargarCategorias= () => {
    categorias.forEach((categoria) => { //voy elemento a elemento de la lista
        const li = document.createElement("li")  //creo un elemento de lista en memoria
        li.innerHTML = `<a href= # >${categoria}</a>` //Define que hay dentro de li

        //Agregar al DOM > mete el elemento dentro de el contenedor listaCategiras
        //Aparece en la pantalla del usuario
        listaCategorias.appendChild(li) 
    });
};

cargarCategorias();

const listaProductos = document.getElementById("contenedor-productos");

//Funcion: cargar productos
const cargarProductos = () => {
    productos.forEach((producto) => {
        const article = document.createElement("article");
        article.className = "producto"; //para usar en el CSS

//Ingresar la informacion dentro de article usando template strings        
        article.innerHTML = `
            <img src="${producto.imagen}" width="200px" alt="${producto.nombre}">
            <h3>${producto.nombre}</h3>
            <p>${producto.descripcion}</p>
            <p><strong>$${producto.precio}</strong></p>
            <button type="button" class = "btnDetalles">Ver Detalles</button>
            <button type="button" class = "btnAgregar">Agregar al Carrito</button>`
        ;
        const btnAgregar = article.querySelector(".btnAgregar"); //Busca dentro del articulo
        btnAgregar.addEventListener("click", () => {
        alert(`Estás agregando ${producto.nombre} al carrito`);
});

        listaProductos.appendChild(article);
    });
};

cargarProductos();