// Array de categorías
const categorias = ["Salchipapas", "Papas rellenas", "Papas Fritas", "Bombas de papa"];


//Array de productos
const productos = [
{
id: 1,
nombre: "Salchipapas clásicas",
descripcion: "Papas fritas y salchicas con mayonesa y ketchup",
precio: 10000,
imagen: "assets/salchipapa.jpg",
categoria: "Salchipapas"
},
{
id: 2,
nombre: "Bombas de papas con queso",
descripcion: "Bombas de papa rellenas de queso con salsa a eleccion",
precio: 10000,
imagen: "assets/bombasdepapa.jfif",
categoria: "Bombas de papa"
},
{
id: 3,
nombre: "Papas rellenas con queso y cebolla",
descripcion: "Papas rellenas con queso cremoso, cebollas de verdeo y queso chedar",
precio: 15000,
imagen: "assets/paparellena.jpg",
categoria: "Papas rellenas"
},
{
id: 4,
nombre: "Papas fritas clásicas",
descripcion: "Papas fritas clásicas con adherezo a eleccion",
precio: 10000,
imagen: "assets/papasfritas.jpg",
categoria: "Papas Fritas"
},


];
