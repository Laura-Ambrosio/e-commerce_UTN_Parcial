import type { CartItem, Product } from "../../../types/product.ts";


//localStorage
//Agregar productos del catalogo > 
//visualizar los elementos agregados en el html}


///////Agregar al storage > se ejecuta en home.ts cuando se presiona el boton agregar

export function agregarAlCarrito(producto: Product) {
    //Crea un nuevo producto en el carrito con cantidad default 1
        const cartNew : CartItem= {
        nombre: producto.nombre,
        precio: producto.precio,
        cantidad: 1,
        imagen: producto.imagen,
            };

        //Comprobar si el producto esta en el carrito o no
        const savedStrings = localStorage.getItem("cartData"); 
        //Si el storage esta vacio porque es el primer producto

        if(savedStrings===null){
            //Convertir a string
            const parseCart = JSON.stringify([cartNew]); 
            //Agregar al storage del carrito
            localStorage.setItem("cartData", parseCart);

        }
        //Si el carrito/storage no esta vacio
        else {
          //Convertir a objeto
            const savedCarrito : Array<CartItem> = JSON.parse(savedStrings); 

          //Si ya existe en el carrito
            if(savedCarrito.some((cartProd) => cartProd.nombre === cartNew.nombre)){
            //Aumentar la cantidad
            savedCarrito.forEach(element => {
                if(element.nombre === cartNew.nombre){
                    let cantidadInicial = element.cantidad;
                    let cantidadFinal= cantidadInicial + 1;
                    element.cantidad = cantidadFinal;
            
            //Guardar cantidad actualizada en el storage
            const parseCart = JSON.stringify(savedCarrito); 
            localStorage.setItem("cartData", parseCart); //guardar
            }
            });
        }
        else{
            //Si no existe pero el carrito tiene productos
            const actualizarCarrito = [...savedCarrito, cartNew];
            //Actualizar el storage del carrito
              const parseCart = JSON.stringify(actualizarCarrito); //convertir a string
              localStorage.setItem("cartData", parseCart); //guardar

        };
    };
};

//////////////Vista del carrito: renderizar localStorage (cartData)

const cargarCarrito = () =>{

    const listaCarrito = document.getElementById("contenedor-carrito");

    //Obtener datos del carrito almacenados en localStorage"cartData"
    const Carrito= localStorage.getItem("cartData");
    

    //Validar que no es null
    if(Carrito != null){
        //Lo convierto en stringJSON
        const SavedCart : Array<CartItem>= JSON.parse(Carrito); 

        SavedCart.forEach((item) => {
        //Crear una "article" por producto en el localStorage
        const articleCarrito = document.createElement("article");
        articleCarrito.className = "productoCarrito"; 
        

        //Limpiar antes de actualizar      
        articleCarrito.innerHTML=""
         //Ingresar la informacion dentro de article usando template strings        
        articleCarrito.innerHTML = `
        <img src="${item.imagen}" width="200px" alt="${item.nombre}">
        <div class="tarjetaCarrito">
            <h3>${item.nombre}</h3>
            <p class="precio"><strong>Precio: $${item.precio}</strong></p>
            <div class="botonesCarrito">
            <button type="button" class = "btnSacar" >-</button>
            <span>${item.cantidad}</span>
            <button type="button" class = "btnAgregar" >+</button>
            <button type="button" class = "btnEliminar">Eliminar</button>
            </div>
        </div>`
        ////////////////Boton Eliminar//////////////////////////////////
        //querySelector > para que c/boton tenga la logica de eliminar
        const btnEliminar=articleCarrito.querySelector(".btnEliminar");

        if(btnEliminar!=null){
        btnEliminar.addEventListener("click", () => {
            //Dependiendo de la cantidad de productos, disminuir o eliminar
            if(item.cantidad > 1){
                ///////////////////////
            let cantidadInicial = item.cantidad;
            let cantidadFinal= cantidadInicial - 1;
            item.cantidad = cantidadFinal;

            //Guardar cantidad actualizada en el storage
            const parseCart = JSON.stringify(SavedCart); 
            localStorage.setItem("cartData", parseCart); 

            }
            else if (item.cantidad===1){

            //Eliminar del storage y guardar
            //dentro del storage que elementos no coinciden con item.nombre 
            //item.nombre es el nombre del producto del botn eliminar
            const actualizarCarrito = SavedCart.filter((producto)=>
            (producto.nombre!=item.nombre));

            //Actualizar el cartData 
            const parseCart = JSON.stringify(actualizarCarrito); 
            localStorage.setItem("cartData", parseCart); 

            }
            //Recargar Vista
            //Limpiar el contenedor
            if(listaCarrito != null){
            listaCarrito.innerHTML = "";
            }
            //Cargarcarrito y precio
            cargarCarrito();

            //Actualizar los valores del total limpiando el contenedor
            const totalContenedor = document.getElementById("contenedor-total");
            if(totalContenedor!=null){
            totalContenedor.className = "totalCarrito"; 
            //Limpiar antes de actalizar      
            totalContenedor.innerHTML=""
            }
            cargarTotal();
        })
    };
        ////////////////////Boton Agregar y Boton Sacar//////////////////////////////////

        const btnAgregar=articleCarrito.querySelector(".btnAgregar");
        const btnSacar=articleCarrito.querySelector(".btnSacar");

        ////Boton Sacar
        if(btnSacar!=null){
        btnSacar.addEventListener("click", () => {
            //Dependiendo de la cantidad de productos, disminuir o eliminar
            if(item.cantidad === 1){
            //Misma logica que con el boton eliminar
            const actualizarCarrito = SavedCart.filter((producto) => producto.nombre != item.nombre);
            const parseCart = JSON.stringify(actualizarCarrito); 
            localStorage.setItem("cartData", parseCart);
            }
            else {
            let cantidadInicial = item.cantidad;
            let cantidadFinal= cantidadInicial - 1;
            item.cantidad = cantidadFinal;

            //Guardar cantidad actualizada en el storage
            const parseCart = JSON.stringify(SavedCart); 
            localStorage.setItem("cartData", parseCart); 

            };

            //Recargar Vista
            //Limpiar el contenedor
            if(listaCarrito != null){
            listaCarrito.innerHTML = "";
            }
            //Cargarcarrito y precio
            cargarCarrito();

            //Actualizar los valores del total limpiando el contenedor
            const totalContenedor = document.getElementById("contenedor-total");
            if(totalContenedor!=null){
            totalContenedor.className = "totalCarrito"; 
            //Limpiar antes de actalizar      
            totalContenedor.innerHTML=""
            };
            cargarTotal();
        })};

        ////Boton Agregar
        if(btnAgregar!=null){
        btnAgregar.addEventListener("click", () => {
            //Agregar 1 a la cantidad
            let cantidadInicial = item.cantidad;
            let cantidadFinal= cantidadInicial + 1;
            item.cantidad = cantidadFinal;

            //Guardar cantidad actualizada en el storage
            const parseCart = JSON.stringify(SavedCart); 
            localStorage.setItem("cartData", parseCart); 

            //Recargar Vista de Productos en el carrito
            //Limpiar el contenedor
            if(listaCarrito != null){
            listaCarrito.innerHTML = "";
            }
            //Cargarcarrito y precio
            cargarCarrito();

            //Actualizar los valores del total limpiando el contenedor
            const totalContenedor = document.getElementById("contenedor-total");
            if(totalContenedor!=null){
            totalContenedor.className = "totalCarrito"; 
            //Limpiar antes de actalizar      
            totalContenedor.innerHTML=""
            };
            cargarTotal();
        })};

        //Agregar los articulos creados a la vista del carrito
        if(listaCarrito != null){
        listaCarrito.appendChild(articleCarrito);
        };
    })};
};
cargarCarrito();

/////Calcular total

const cargarTotal = () =>{
    //Obtener datos del carrito almacenados en localStorage"cartData"

    const totalContenedor = document.getElementById("contenedor-total");
    const Carrito= localStorage.getItem("cartData");

    //Validar que no es null
    if(Carrito != null){
    //Lo convierto en objeto
    const SavedCart : Array<CartItem>= JSON.parse(Carrito); 

    //Puedo usar reduce para acumular valores, esos valores puede ser el resultado de una operacion. (cantidad*precio)
    const total = SavedCart.reduce((acumulador, elemento) => acumulador + (elemento.cantidad * elemento.precio), 0);
    
    //Crear una "article" por producto en el localStorage
        const totalCarrito = document.createElement("article");
        totalCarrito.className = "totalCarrito"; 
        
        //Limpiar antes de actalizar      
        totalCarrito.innerHTML=""
         //Ingresar la informacion dentro de article usando template strings        
        totalCarrito.innerHTML = `
            <p class="totalCarrito">El total es $${total}</p>`
            
        //Agregar cada articulo al contenedor "listaCarrito"
        if(totalContenedor !=null){
            totalContenedor.appendChild(totalCarrito);
        };

};
};

cargarTotal();

