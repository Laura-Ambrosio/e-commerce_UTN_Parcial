///////////Import de la Logica del repositorio base
//import { checkAuhtUser, logout } from "../../../utils/auth";

///////////Importa de la Logica del parcial
import { PRODUCTS } from "../../../data/data.ts";
import { CATEGORIAS } from "../../../data/data.ts";
import type { Product } from "../../../types/product.ts";
import { agregarAlCarrito } from "../cart/cart.ts";

const listaCategorias = document.getElementById("lista-categorias");

//Funcion: cargar categorias
//Carga las categorias en la pagina
const cargarCategorias= () => {
    CATEGORIAS .forEach((categoria) => { //voy elemento a elemento de la lista
        const li = document.createElement("li")  //creo un elemento de lista en memoria
        li.innerHTML = `<a href= # >${categoria.nombre}</a>` //Define que hay dentro de li

        //Agregar al DOM > mete el elemento dentro de el contenedor listaCategiras
        //Aparece en la pantalla del usuario

        //TS, debo verificar que no sea null antes de agregar a la lista
        if(listaCategorias!=null){
        listaCategorias.appendChild(li) 
        }
    });
};

cargarCategorias();

const listaProductos = document.getElementById("contenedor-productos");

//Funcion: cargar productos
const cargarProductos = (Productos : Array<Product>) => {
    Productos.forEach((producto) => {
        const article = document.createElement("article");
        article.className = "producto"; //para usar en el CSS

//Ingresar la informacion dentro de article usando template strings        
        article.innerHTML = `
            <img src="${producto.imagen}" width="200px" alt="${producto.nombre}">
            <h3>${producto.nombre}</h3>
            <p class="descripcion">${producto.descripcion}</p>
            <p class="precio"><strong>$${producto.precio}</strong></p>
            <div class="botonesProducto">
            <button type="button" class = "btnDetalles">Ver Detalles</button>
            <button type="button" class = "btnAgregar">Agregar al Carrito</button>
            </div>`
            
        const btnAgregar = article.querySelector(".btnAgregar"); //Busca dentro del articulo
        
        if(btnAgregar!=null){
        btnAgregar.addEventListener("click", () => {
        agregarAlCarrito(producto);
        alert(`Estás agregando ${producto.nombre} al carrito`);
        })
      };

        if(listaProductos!=null){
        listaProductos.appendChild(article);
        };
    });
};

cargarProductos(PRODUCTS);


///////Buscar productos
//Crear elementos
const searchInput = document.getElementById("busqueda") as HTMLInputElement;
const form = document.getElementById("formBusqueda") as HTMLFormElement;

//Si elemento buttonSearch existe agregar un listener
form.addEventListener("submit", (e: SubmitEvent) => {
  e.preventDefault();

  //Buscar si hay coincidencia en cada elemento de la lista
  const resultadosBusqueda = PRODUCTS.filter((producto) =>
    ((producto.nombre.toLowerCase()).includes((searchInput.value.toLowerCase()))));
  
  //Si no hay coincidencia, el array esta vacio
  if(resultadosBusqueda.length===0){

    //Validar que lista productos no es null 
    if (listaProductos!= null){
      //Mostrar mensaje de error
      listaProductos.innerHTML = `
      <p>"No se encontro coincidencia para "${searchInput.value}""</p>`
    }}
    else {
    //cargar los resultados en la pagina
    if(listaProductos!=null){
    listaProductos.innerHTML="";
    cargarProductos(resultadosBusqueda);
    }}
    ;
  
});

////////////Filtrar por categoria

listaCategorias?.addEventListener('click',(e) => {
//Detectar un evento (e))
//Identificar cual genero el evento (target) 
//Obtener el texto (textContent)
  const categoriaSeleccionada = (e.target as HTMLElement).textContent;
  //console.log(categoriaSeleccionada); //Funciona

  //Ver Todos
  if(categoriaSeleccionada === "Ver Todos") {
    if(listaProductos!=null){
    listaProductos.innerHTML="";
    cargarProductos(PRODUCTS);
    };
  }
  else{
//Buscar la categoria en PRODUCTS y crear un nuevo array
  const productosPorCategoria = PRODUCTS.filter((producto) => 
  (producto.categoria.includes(categoriaSeleccionada)));
//console.log(productosPorCategoria); //Error > {} requiere return


//Cargar el Array con la funcion Cargar Productos
    //cargar los resultados en la pagina
    if(listaProductos!=null){
    listaProductos.innerHTML="";
    cargarProductos(productosPorCategoria);
    };
}
});


/*
///////////Logica del repositorio base
const buttonLogout = document.getElementById(
  "logoutButton"
) as HTMLButtonElement;

buttonLogout?.addEventListener("click", () => {
  logout();
});


const initPage = () => {
  console.log("inicio de pagina");
  checkAuhtUser(
    "/src/pages/auth/login/login.html",
    "/src/pages/admin/home/home.html",
    "client"
  );
};

initPage();
*/