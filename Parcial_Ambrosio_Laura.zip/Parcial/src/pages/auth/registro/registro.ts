import type { IRegisteredUsers } from "../../../types/IRegisteredUsers";

const form = document.getElementById("form") as HTMLFormElement;
const inputEmail = document.getElementById("email") as HTMLInputElement;
const inputPassword = document.getElementById("password") as HTMLInputElement;

form.addEventListener("submit", (e: SubmitEvent) => {
  e.preventDefault();
  const valueEmail = inputEmail.value;
  const valuePassword = inputPassword.value;

  const userNew : IRegisteredUsers= {
    email: valueEmail,
    password: valuePassword,
  };

//traigo lo que haya en storage, esta almacenado como "usersData"
const savedStrings = localStorage.getItem("usersData"); 

//Si esta vacio porque es el primer dato ingresado
if(savedStrings=== null){

  //Convertir a string y agregar al localStorage
  const parseUsers = JSON.stringify([userNew]); //convierte en string
  localStorage.setItem("usersData", parseUsers); //guarda en storage 
}

else {

//Si el storage no esta vacio

    //Convertir lo que ya tengo a un array tipado
    //Lo convierto en array de objetos y le dice a TS que tienen la forma de IRegisteredUser
    const savedObjects : Array<IRegisteredUsers> = JSON.parse(savedStrings); 

//Verificar que no este registrado antes
//Some devuelve true si se cumple
    if(savedObjects.some((user) => user.email === userNew.email)) {
        //Si ya esta registrado mostrar una alerta
        alert("Ese usuario ya esta registrado");

}
    else {
            //Si no esta registrado
//Desempaqueta savedObjects que pasa de array a objetos y lo junta con users que esta como objeto
//Para crear un array de objetos
   const users = [...savedObjects, userNew]; 

//Actualizar el storage de usuarios
  //Convierte en string
  const parseUsers = JSON.stringify(users); //convierte en string
  localStorage.setItem("usersData", parseUsers); //guarda en storage 

}
}

console.log(localStorage.getItem("usersData"))

});