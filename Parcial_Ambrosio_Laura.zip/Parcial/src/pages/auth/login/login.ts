import type { IUser } from "../../../types/IUser";
import type { Rol } from "../../../types/Rol";
import { navigate } from "../../../utils/navigate";
import type { IRegisteredUsers } from "../../../types/IRegisteredUsers";

const form = document.getElementById("form") as HTMLFormElement;
const inputEmail = document.getElementById("email") as HTMLInputElement;
const inputPassword = document.getElementById("password") as HTMLInputElement;
const selectRol = document.getElementById("rol") as HTMLSelectElement;

form.addEventListener("submit", (e: SubmitEvent) => {
  e.preventDefault();
  const valueEmail = inputEmail.value;
  const valuePassword = inputPassword.value;
  const valueRol = selectRol.value as Rol;

  const user: IUser = {
  email: valueEmail,
  role: valueRol,
  loggedIn: true,
  };

  //Generar el array users con los valores de localStore para comparar
  const usersString = localStorage.getItem("usersData"); //strin

  if(usersString === null){
  alert("No hay usuario registrados en localStorage");
  }
  else {
  //Si NO es null, convierte en array
  const users : Array<IRegisteredUsers> = JSON.parse(usersString); 

    //Verificar que existe el usuario y contraseña
    //Si existe agregar el usuario al local
    if(users.some((usuario) => usuario.email === valueEmail && usuario.password === valuePassword)){

        //Comprobar role e iniciar sesion (tiene que tener usuario)
        if (valueRol === "admin") {
        navigate("/src/pages/admin/home/home.html");
        
          } else if (valueRol === "client") {
          navigate("src/pages/store/home/home.html");
          }

        //Guardar el usuario para iniciar sesion
        const parseUser = JSON.stringify(user);
        localStorage.setItem("userData", parseUser);
    }    
    else {
      alert("El usuario, contraseña o el rol no son correctos");
    };
  }
}
);
