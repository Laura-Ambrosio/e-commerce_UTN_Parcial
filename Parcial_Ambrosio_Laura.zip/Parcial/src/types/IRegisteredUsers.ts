export interface IRegisteredUsers {
  email: string;
  password: string;
}