//import type { IUser } from "./types/IUser";
//import { navigate } from "./utils/navigate";

//Que las paginas no sean accesibles mediante url si no hay sesion

//Crear una funcion que intercepte la carga de la pagina


/*
//Determinar si esta logueado
function estaLogueado(): boolean{

    let estaLogueado=false;

    //Obtener UserData de la pagina actual
    const userData = localStorage.getItem("userData"); 
        if(userData!=null){
        let estaLogueado=true; 
        return estaLogueado; //true
        }
    return estaLogueado; //false
    
};

//Obtener datos de login y redirigir

if(estaLogueado()){
    const userData = localStorage.getItem("userData")
    if(userData != null){
        const user : IUser= JSON.parse(userData);

        //Verifica si el path actual incluye las palabras client y admin
        if((window.location.pathname.includes("/client/")) && user.role ==="admin"){            
            //Redirigir al loguin
            navigate("/src/pages/admin/home/home.html");
        }
        else if((window.location.pathname.includes("/admin/")) && user.role ==="client"){
            navigate("src/pages/store/home/home.html");
        };
    };
}
    else {
        //Si no esta logueado
        navigate("/src/pages/auth/login/login.html");
    };
*/










